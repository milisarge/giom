stdnum.ec.ruc
=============

.. automodule:: stdnum.ec.ruc
   :members:
