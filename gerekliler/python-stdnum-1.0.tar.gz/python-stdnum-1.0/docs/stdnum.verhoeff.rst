stdnum.verhoeff
===============

.. automodule:: stdnum.verhoeff
   :members:
