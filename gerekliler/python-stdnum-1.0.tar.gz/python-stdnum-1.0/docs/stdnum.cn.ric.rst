stdnum.cn.ric
=============

.. automodule:: stdnum.cn.ric
   :members:
