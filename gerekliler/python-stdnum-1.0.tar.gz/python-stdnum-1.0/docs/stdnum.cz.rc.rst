stdnum.cz.rc
============

.. automodule:: stdnum.cz.rc
   :members:
