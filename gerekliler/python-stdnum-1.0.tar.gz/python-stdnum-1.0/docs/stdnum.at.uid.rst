stdnum.at.uid
=============

.. automodule:: stdnum.at.uid
   :members:
