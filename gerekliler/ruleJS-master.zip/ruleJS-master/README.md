RuleJS
=======
Like excel library to parse formulas ([demo](http://handsontable.github.io/ruleJS/))

## How to run
- npm install
- grunt start (open in browser http://localhost:8080)

## License
The MIT License (see the [LICENSE](https://github.com/Berus/RuleJS/blob/master/LICENSE) file for the full text)


